console.log("a....");
let b = 10;
let c = 20;
export {b,c} //多个

// export default b; //一个
export {b as default}