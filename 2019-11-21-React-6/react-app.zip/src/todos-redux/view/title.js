import React from 'react';
function Title(){
    return (<div className="title">
        <h1>todos</h1>
    </div>);
}

export default Title;
