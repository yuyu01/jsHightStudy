import React from 'react';
import Inner from './inner';
function App(props) {
  return (
    <div className="App">
      <Inner name="kkb" />
    </div>
  );
}

export default App;
